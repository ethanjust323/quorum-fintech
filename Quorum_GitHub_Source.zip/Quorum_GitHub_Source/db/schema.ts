import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
export const rooms = sqliteTable("quorum_rooms", {id:text("id").primaryKey(), state:text("state").notNull(), version:integer("version").notNull().default(0), updated:integer("updated").notNull()});
